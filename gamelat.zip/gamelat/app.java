import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.FileInputStream;
import java.util.*;

public class app extends Application {
    private static final int size = 4;
    private static final int KICH_THUOC_HINH = 80;

    private String[][] duongDanHinhAnh = new String[size][size];
    private boolean[][] daLat = new boolean[size][size];
    private Button[][] nutHinh = new Button[size][size];

    private Button nutThuNhat = null;
    private Button nutThuHai = null;

    private int soLuongDaLat = 0;
    private int soLuotChoi = 0;
    private Label nhanLuotChoi = new Label("Lượt chơi: 0");

    private final String HINH_BIA = "images/back.png";
    private boolean dangKiemTra = false;

    @Override
    public void start(Stage manChoi) {
        taoBanChoi();

        GridPane luoi = new GridPane();
        luoi.setPadding(new Insets(20));
        luoi.setHgap(10);
        luoi.setVgap(10);
        luoi.setAlignment(Pos.CENTER);

        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                Button nut = taoNutHinh(i, j);
                nutHinh[i][j] = nut;
                luoi.add(nut, j, i);
            }
        }

        VBox root = new VBox(15, nhanLuotChoi, luoi);
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(20));

        Scene manHinh = new Scene(root);
        manChoi.setTitle("🎮 Trò Chơi Lật Hình 4x4");
        manChoi.setScene(manHinh);
        manChoi.show();
    }

    private void taoBanChoi() {
        List<String> danhSachHinh = new ArrayList<>();
        for (char c = 'A'; c <= 'H'; c++) {
            danhSachHinh.add("images/" + c + ".png");
            danhSachHinh.add("images/" + c + ".png");
        }
        Collections.shuffle(danhSachHinh);
        for (int i = 0; i < size * size; i++) {
            duongDanHinhAnh[i / size][i % size] = danhSachHinh.get(i);
        }
    }

    private Button taoNutHinh(int hang, int cot) {
        Button nut = new Button();
        nut.setPrefSize(KICH_THUOC_HINH + 10, KICH_THUOC_HINH + 10);
        try {
            datHinhAnh(nut, HINH_BIA);
        } catch (Exception e) {
            e.printStackTrace();
        }

        nut.setUserData(new int[]{hang, cot});
        nut.setOnAction(e -> xuLyClick(nut));
        return nut;
    }

    private void xuLyClick(Button nut) {
        if (dangKiemTra) return;

        int[] viTri = (int[]) nut.getUserData();
        int hang = viTri[0];
        int cot = viTri[1];

        if (daLat[hang][cot] || nut == nutThuNhat) return;

        try {
            datHinhAnh(nut, duongDanHinhAnh[hang][cot]);
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        if (nutThuNhat == null) {
            nutThuNhat = nut;
        } else {
            nutThuHai = nut;
            dangKiemTra = true;
            soLuotChoi++;
            nhanLuotChoi.setText("Lượt chơi: " + soLuotChoi);

            int[] viTri1 = (int[]) nutThuNhat.getUserData();
            int[] viTri2 = (int[]) nutThuHai.getUserData();
            int h1 = viTri1[0], c1 = viTri1[1];
            int h2 = viTri2[0], c2 = viTri2[1];

            if (duongDanHinhAnh[h1][c1].equals(duongDanHinhAnh[h2][c2])) {
                daLat[h1][c1] = true;
                daLat[h2][c2] = true;
                soLuongDaLat += 2;

                nutThuNhat = null;
                nutThuHai = null;
                dangKiemTra = false;

                if (soLuongDaLat == size * size) {
                    nhanLuotChoi.setText("🎉 Bạn đã hoàn thành sau " + soLuotChoi + " lượt");
                }
            } else {
                Timer dongHo = new Timer();
                dongHo.schedule(new TimerTask() {
                    public void run() {
                        Platform.runLater(() -> {
                            try {
                                datHinhAnh(nutThuNhat, HINH_BIA);
                                datHinhAnh(nutThuHai, HINH_BIA);
                            } catch (Exception ex) {
                                ex.printStackTrace();
                            }
                            nutThuNhat = null;
                            nutThuHai = null;
                            dangKiemTra = false;
                        });
                    }
                }, 700);
            }
        }
    }

    private void datHinhAnh(Button nut, String duongDan) throws Exception {
        Image hinh = new Image(new FileInputStream(duongDan), KICH_THUOC_HINH, KICH_THUOC_HINH, true, true);
        nut.setGraphic(new ImageView(hinh));
    }

    public static void main(String[] args) {
        launch(args);
    }
}
